import os, sqlite3, time
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.utils import secure_filename

BASE=os.path.dirname(os.path.abspath(__file__)); DB=os.path.join(BASE,'portfolio.db'); UP=os.path.join(BASE,'static','uploads')
os.makedirs(UP,exist_ok=True)
app=Flask(__name__); app.secret_key=os.environ.get('SECRET_KEY','change-this-secret-key'); app.config['MAX_CONTENT_LENGTH']=80*1024*1024
ADMIN_USER=os.environ.get('ADMIN_USER','admin'); ADMIN_PASSWORD=os.environ.get('ADMIN_PASSWORD','muthu123')
IMG={'jpg','jpeg','png','webp','gif'}; VID={'mp4','webm','mov'}

def db():
 c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

def init():
 c=db(); c.execute('''CREATE TABLE IF NOT EXISTS media(id INTEGER PRIMARY KEY AUTOINCREMENT,filename TEXT,title TEXT,category TEXT,media_type TEXT,description TEXT,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
 if c.execute('SELECT COUNT(*) n FROM media').fetchone()['n']==0:
  rows=[('motorcycle-night.jpg','Midnight Rider','Cinematic','image'),('lotus-lake.jpg','Still Water','Nature','image'),('lotus-closeup.jpg','In Bloom','Nature','image'),('waterfall-adventure.jpg','Into The Wild','Travel','image'),('sunset-silhouette.jpg','Golden Hour','Cinematic','image')]
  c.executemany('INSERT INTO media(filename,title,category,media_type) VALUES(?,?,?,?)',rows); c.commit()
 c.close()

def auth(f):
 @wraps(f)
 def w(*a,**k): return f(*a,**k) if session.get('admin') else redirect(url_for('login',next=request.path))
 return w

def media_url(x): return url_for('static',filename='uploads/'+x['filename'])
app.context_processor(lambda:{'media_url':media_url})

@app.route('/')
def home():
 cat=request.args.get('category','All'); c=db(); rows=c.execute('SELECT * FROM media WHERE category=? OR ?="All" ORDER BY id DESC',(cat,cat)).fetchall(); c.close(); return render_template('index.html',media=rows,category=cat)
@app.route('/admin/login',methods=['GET','POST'])
def login():
 if request.method=='POST' and request.form.get('username')==ADMIN_USER and request.form.get('password')==ADMIN_PASSWORD:
  session['admin']=True; return redirect(request.args.get('next') or url_for('admin'))
 if request.method=='POST': flash('Invalid username or password.','error')
 return render_template('login.html')
@app.route('/admin/logout')
def logout(): session.clear(); return redirect(url_for('home'))
@app.route('/admin')
@auth
def admin():
 c=db(); rows=c.execute('SELECT * FROM media ORDER BY id DESC').fetchall(); c.close(); return render_template('admin.html',media=rows)
@app.route('/admin/upload',methods=['POST'])
@auth
def upload():
 f=request.files.get('file'); title=request.form.get('title','').strip(); cat=request.form.get('category','Cinematic'); desc=request.form.get('description','')
 if not f or not f.filename: flash('Choose a file.','error'); return redirect(url_for('admin'))
 ext=f.filename.rsplit('.',1)[-1].lower() if '.' in f.filename else ''
 if ext in IMG: typ='image'
 elif ext in VID: typ='video'
 else: flash('Use JPG, PNG, WEBP, MP4, WEBM or MOV.','error'); return redirect(url_for('admin'))
 safe=secure_filename(f.filename); name=f'{int(time.time())}_{safe}'; f.save(os.path.join(UP,name)); title=title or os.path.splitext(safe)[0].replace('-',' ').replace('_',' ').title()
 c=db(); c.execute('INSERT INTO media(filename,title,category,media_type,description) VALUES(?,?,?,?,?)',(name,title,cat,typ,desc)); c.commit(); c.close(); flash('Published successfully.','success'); return redirect(url_for('admin'))
@app.route('/admin/edit/<int:i>',methods=['POST'])
@auth
def edit(i):
 c=db(); c.execute('UPDATE media SET title=?,category=?,description=? WHERE id=?',(request.form['title'],request.form['category'],request.form.get('description',''),i)); c.commit(); c.close(); flash('Updated.','success'); return redirect(url_for('admin'))
@app.route('/admin/delete/<int:i>',methods=['POST'])
@auth
def delete(i):
 c=db(); x=c.execute('SELECT * FROM media WHERE id=?',(i,)).fetchone()
 if x:
  p=os.path.join(UP,x['filename']); os.path.isfile(p) and os.remove(p); c.execute('DELETE FROM media WHERE id=?',(i,)); c.commit()
 c.close(); flash('Deleted.','success'); return redirect(url_for('admin'))

init()
if __name__=='__main__': app.run(host='0.0.0.0',port=int(os.environ.get('PORT',5000)),debug=True)
